import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import joblib

# Load dataset
df = pd.read_csv('IMDb Movies India.csv', comment='#', encoding='ISO-8859-1')
df = df.dropna(subset=['Rating'])

# Clean and convert columns
df['Duration'] = df['Duration'].str.extract(r'(\d+)').astype(float)
df['Votes'] = df['Votes'].astype(str).str.replace(',', '', regex=False)
df['Votes'] = pd.to_numeric(df['Votes'], errors='coerce')
df['Votes'] = df['Votes'].fillna(df['Votes'].median())

# Fill missing categorical values
cat_cols = ['Genre', 'Director', 'Actor 1', 'Actor 2', 'Actor 3']
df[cat_cols] = SimpleImputer(strategy='most_frequent').fit_transform(df[cat_cols])

# ✅ Precompute average ratings
director_avg_rating = df.groupby('Director')['Rating'].mean()
genre_avg_rating_map = {}

# Precompute genre average ratings
for genre in df['Genre'].dropna().str.split(',').explode().str.strip().unique():
    genre_avg_rating_map[genre] = df[df['Genre'].str.contains(genre, na=False)]['Rating'].mean()

# Add features
df['Director_Success'] = df['Director'].map(director_avg_rating)
df['Genre_Avg_Rating'] = df['Genre'].apply(
    lambda x: np.mean([genre_avg_rating_map.get(g.strip(), np.nan) for g in x.split(',')])
)

# One-hot encode genres
genre_dummies = df['Genre'].str.get_dummies(sep=',')
df = pd.concat([df, genre_dummies], axis=1)

# Define features
features = ['Duration', 'Votes', 'Director_Success', 'Genre_Avg_Rating'] + list(genre_dummies.columns)
X = df[features].fillna(df[features].median())
y = df['Rating']

# Train model (save for reuse)
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)
joblib.dump((model, features, director_avg_rating, genre_avg_rating_map, genre_dummies.columns), 'model.pkl')

# ---------- FAST PREDICTION ----------
def predict_movie_rating():
    model, features, director_avg, genre_avg_map, genre_columns = joblib.load('model.pkl')

    print("\n--- Enter New Movie Details ---")
    duration = float(input("Enter duration (in minutes): "))
    votes = int(input("Enter number of votes: ").replace(',', ''))
    director = input("Enter director name: ")
    genre = input("Enter genre(s) (comma separated): ")

    director_success = director_avg.get(director, director_avg.mean())
    genres = [g.strip() for g in genre.split(',')]
    genre_avg = np.mean([genre_avg_map.get(g, np.nan) for g in genres])
    genre_avg = genre_avg if not np.isnan(genre_avg) else np.nanmean(list(genre_avg_map.values()))

    # One-hot genre encoding
    genre_data = {col: 1 if col in genres else 0 for col in genre_columns}
    user_data = pd.DataFrame([{
        'Duration': duration,
        'Votes': votes,
        'Director_Success': director_success,
        'Genre_Avg_Rating': genre_avg,
        **genre_data
    }])

    # Ensure all columns exist
    for col in features:
        if col not in user_data.columns:
            user_data[col] = 0

    user_data = user_data[features]
    rating = model.predict(user_data)[0]
    print(f"\n🎬 Predicted Movie Rating: {rating:.2f}")

# Run prediction
predict_movie_rating()
